# Power-Bi-SQL-1
Power Bi &amp; SQL-1 by Crux International CANADA
